export interface RegionComputeRequestDTO {
  lat: number;
  lon: number;
  side_km: number;
  zones_per_edge: number;
}
